<?php require "template/header.php";
        require "template/sidebar.php";?>
<div id="center">
    <h2 style="margin-left: 50px">Products</h2>
    <div id="get_product">
        </div>
</div>
<p id="footer">© Sandra Masiwa 2022</p>
<?php require "template/footer.php";?>

<script src="js/jquery2.js"></script>
<script src="js/index.js"></script>