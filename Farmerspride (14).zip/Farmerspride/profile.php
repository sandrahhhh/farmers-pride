<?php require "template/profile.php";?>
<?php require "template/sidebar.php";?>
<div id="center">
    <h2 style="margin-left: 50px">Products</h2>
    <div id="get_product">
        </div>

        <!-- Modal -->
  <div class="modal fade" id="addProduct" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-body">
          <p>Added to cart</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
</div>
<p id="footer">© Sandra Masiwa 2022</p>
<?php require "template/footer.php";?>