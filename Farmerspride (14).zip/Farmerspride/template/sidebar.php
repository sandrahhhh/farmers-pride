<div id = 'side_bar'>
<h3>Product Categories</h3>
<ul>
<div id="get_category">
</div>
</ul>
</div>